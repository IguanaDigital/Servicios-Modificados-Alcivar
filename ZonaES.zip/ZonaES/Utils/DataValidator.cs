﻿using ReyBanPac.ModeloCanonico.Utils;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ZonaES.Utils
{
    public static class DataValidator
    {
        public static string ValidarResultadoByCreate(ZonaType EntityType)
        {
            if (EntityType == null)
            {
                throw new ServiceException("Error al crear el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "Registro creado con id: " + EntityType.Id;
        }

        public static string ValidarResultadoByUpdate(ZonaType EntityType)
        {
            if (EntityType == null)
            {
                throw new ServiceException("Error al actualizar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            return "El registro con id: " + EntityType.Id + " fue actualizado de forma exitosa";
        }

        public static string ValidarResultadoByDelete(int Confirmacion)
        {
            if (Confirmacion == 0)
            {
                throw new ServiceException("Error al eliminar el registro") { Codigo = StatusCodes.Status400BadRequest };
            }
            else
            {
                return "Registro eliminado de forma exitosa";
            }

        }
        public static Object ValidarResultadoConsulta(List<ZonaType> Configuracion)
        {
            if (Configuracion != null)
            {
                return Configuracion;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }

        public static Object ValidarResultadoConsulta(ZonaType EntityType)
        {
            if (EntityType != null)
            {
                return EntityType;
            }
            else
            {
                throw new ServiceException("No hay Contenido") { Codigo = StatusCodes.Status404NotFound };
            }
        }
    }
}
