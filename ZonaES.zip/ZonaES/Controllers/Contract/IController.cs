﻿using Microsoft.AspNetCore.Mvc;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.ZonaES.Controllers.Contract
{
    public interface IController
    {

        public Task<ActionResult<object>> Consultar();

        public Task<ActionResult<object>> ConsultarPorId(string Id);



    }
}
