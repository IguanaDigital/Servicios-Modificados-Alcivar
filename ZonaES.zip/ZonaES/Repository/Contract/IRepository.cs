﻿using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.ZonaES.Repository.Contract
{
    public interface IRepository
    {
        public Task<List<ZonaModel>> Consultar();

        public Task<ZonaModel> ConsultarPorId(string Id);

        public Task<List<ZonaModel>> ConsultarPorEncuestaId(int Id_Encuesta);

        public Task<List<ZonaModel>> ConsultarPorDashboardId(int Id_Encuesta);

    }
}
