﻿using Microsoft.EntityFrameworkCore;
using System.Reflection;
using ReyBanPac.ModeloCanonico.Constans;
using ReyBanPac.ZonaES.Constans;
using ReyBanPac.ZonaES.Repository.Contract;
using ReyBanPac.ZonaES.Repository.Context;
using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.ZonaES.Repository.Impl
{
    public class RepositoryImpl : IRepository
    {
        private readonly Db db;
        private readonly ILogger<RepositoryImpl> _logger;
        public RepositoryImpl(Db dbContex, ILogger<RepositoryImpl> logger)
        {
            this.db = dbContex;
            _logger = logger;
        }

        public async Task<List<ZonaModel>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                return await db.Models.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<List<ZonaModel>> ConsultarPorEncuestaId(int Id_Encuesta)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                return await (from z in db.Models
                              join eh in db.EmpleadoHaciendaModel on z.Id equals eh.Id_Zona
                              join h in db.HaciendaModel on eh.Id_Hacienda equals h.Id
                              join pd in db.PermisoDispositivoModel on h.Id equals pd.Id_Hacienda
                              join e in db.EncuestaModel on pd.Id_Encuesta equals e.Id
                              where z.Estado == Estados.ACTIVO &&
                                    e.Estado == Estados.ACTIVO &&
                                    e.Id == Id_Encuesta
                              select z).Distinct().ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

        public async Task<ZonaModel> ConsultarPorId(string Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                return await db.Models.FindAsync(Id) ?? new ZonaModel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }


        public async Task<List<ZonaModel>> ConsultarPorDashboardId(int Id_Encuesta)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Inicio Repository");

            try
            {
                return await (from z in db.Models
                              join eh in db.EmpleadoHaciendaModel on z.Id equals eh.Id_Zona
                              join h in db.HaciendaModel on eh.Id_Hacienda equals h.Id
                              join pd in db.RegistroConsentimientoModel on eh.Id equals pd.Id_Persona
                              join e in db.EncuestaModel on pd.Id_Encuesta equals e.Id
                              where e.Id == Id_Encuesta
                              select z).Distinct().ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  {MethodBase.GetCurrentMethod()?.DeclaringType?.DeclaringType?.FullName ?? ""} Fin Repository");
            }
        }

    }
}
