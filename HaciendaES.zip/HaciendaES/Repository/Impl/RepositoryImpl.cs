﻿using ReyBanPac.HaciendaES.Constans;
using ReyBanPac.HaciendaES.Repository.Contract;
using ReyBanPac.HaciendaES.Repository.Context;
using ReyBanPac.ModeloCanonico.Model;
using Microsoft.EntityFrameworkCore;

using ReyBanPac.ModeloCanonico.Constans;

namespace ReyBanPac.HaciendaES.Repository.Impl
{
    public class RepositoryImpl : IRepository
    {
        private readonly Db db;
        private readonly ILogger<RepositoryImpl> _logger;
        public RepositoryImpl(Db dbContex, ILogger<RepositoryImpl> logger)
        {
            this.db = dbContex;
            _logger = logger;
        }

        public async Task<List<HaciendaModel>> Consultar()
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<HaciendaModel> ConsultarPorId(string Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await db.Models.FindAsync(Id) ?? new HaciendaModel();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

        public async Task<List<HaciendaModel>> ConsultarPorZonaId(string Id)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await (from e in db.EmpleadoHaciendaModels
                                  join h in db.Models on e.Id_Hacienda equals h.Id
                                  where e.Id_Zona.Equals(Id) && e.Estado == Estados.ACTIVO
                                  select h).Distinct().ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }


        public async Task<List<HaciendaModel>> ConsultarPorZonaEncuestaId(string Id_Zona,int Id_Encuesta)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await (from eh in db.EmpleadoHaciendaModels
                    join h in db.Models on eh.Id_Hacienda equals h.Id
                    join pd in db.PermisoDispositivoModel on h.Id equals pd.Id_Hacienda
                    join e in db.EncuestaModel on pd.Id_Encuesta equals e.Id
                    where eh.Id_Zona.Equals(Id_Zona) &&
                          eh.Estado == Estados.ACTIVO &&
                          e.Estado == Estados.ACTIVO
                    select h).Distinct().ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }


        public async Task<List<HaciendaModel>> ConsultarPorZonaEncuestaDashboardId(string Id_Zona, int Id_Encuesta)
        {
            _logger.LogInformation($"{General.Nombre_Servicio}  Inicio Repository");

            try
            {
                return await (from eh in db.EmpleadoHaciendaModels
                              join h in db.Models on eh.Id_Hacienda equals h.Id
                              join pd in db.RegistroConsentimientoModel on eh.Id equals pd.Id_Persona
                              join e in db.EncuestaModel on pd.Id_Encuesta equals e.Id
                              where eh.Id_Zona.Equals(Id_Zona) &&
                              e.Id.Equals(Id_Encuesta)
                              select h).Distinct().ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{General.Nombre_Servicio}  Error Interno del Servidor");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{General.Nombre_Servicio}  Fin Repository");
            }
        }

    }
}
