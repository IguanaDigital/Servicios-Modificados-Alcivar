﻿using ReyBanPac.ModeloCanonico.Model;

namespace ReyBanPac.HaciendaES.Repository.Contract
{
    public interface IRepository
    {
        public Task<List<HaciendaModel>> Consultar();

        public Task<HaciendaModel> ConsultarPorId(string Id);

        public Task<List<HaciendaModel>> ConsultarPorZonaId(string Id);

        public Task<List<HaciendaModel>> ConsultarPorZonaEncuestaId(string Id_Zona, int Id_Encuesta);

        public Task<List<HaciendaModel>> ConsultarPorZonaEncuestaDashboardId(string Id_Zona, int Id_Encuesta);

    }
}
