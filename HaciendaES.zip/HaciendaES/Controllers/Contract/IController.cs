﻿using ReyBanPac.ModeloCanonico.Type;
using Microsoft.AspNetCore.Mvc;

namespace ReyBanPac.HaciendaES.Controllers.Contract
{
    public interface IController
    {
        public Task<ActionResult<Object>> Consultar();

        public Task<ActionResult<Object>> ConsultarPorId(string Id);
        public Task<ActionResult<Object>> ConsultarPorZonaId(string Id);

        public Task<ActionResult<Object>> ConsultarPorZonaEncuestaId(string Id_Zona, int Id_Encuesta);

        public Task<ActionResult<Object>> ConsultarPorZonaEncuestaDashboardId(string Id_Zona, int Id_Encuesta);

    }
}
