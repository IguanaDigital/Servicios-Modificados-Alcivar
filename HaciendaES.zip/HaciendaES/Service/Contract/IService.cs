﻿using ReyBanPac.ModeloCanonico.Model;
using ReyBanPac.ModeloCanonico.Type;

namespace ReyBanPac.HaciendaES.Service.Contract
{
    public interface IService
    {
       
        public Task<List<HaciendaType>> Consultar();

        public Task<HaciendaType> ConsultarPorId(string Id);

        public Task<List<HaciendaType>> ConsultarPorZonaId(string Id);

        public Task<List<HaciendaType>> ConsultarPorZonaEncuestaId(string Id_Zona, int Id_Encuesta);

        public Task<List<HaciendaType>> ConsultarPorZonaEncuestaDashboardId(string Id_Zona, int Id_Encuesta);

    }
}
